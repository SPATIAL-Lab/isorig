# rescale and geographic assignment for RBK result

RBK_cal.pdRaster <- function(known, unknown, dir = "./", mask = NULL, interpMethod = 2, NA.value = NA, ignore.NA = T, sim = 100){

  setwd(dir)

  for (i in 0:(sim-1))
  {
    predN=paste("pred",i,sep = '')
    rescaleN = paste("rescale", i, sep='')
    assignN = paste("assign", i, sep='')
    predictionN=paste("prediction_", i , ".txt", sep='')
    if(file.exists(predictionN))
    {
      assign(predN, read.table(predictionN,sep="\t",header = T))
      rasterFromXYZ(get(predN)[])
      assign(rescaleN, calRaster(known, predN, mask = mask))
      assign(assginN, pdRaster(get(rescaleN)@isoscape.rescale$mean, get(rescaleN)@isoscape.rescale$sd), unknown, mask = mask)
    }
    else
    {
      noPredFile = append(noPredFile,predN)
      assign(predN,NULL)
    }
  }


}
